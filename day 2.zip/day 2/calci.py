def add(x,y):
    return x+y
def sub(x,y):
    return x-y
def mul(x,y):
    return x*y
def div(x,y):
    return x/y
def calci():
    print("selection")
    print("1.addition")
    print("2.subraction")
    print("3.multipication")
    print("4.division")
    c=int(input("enter your choice"))
    x=float(input("enter your frist nuumber"))
    y=float(input("enter your second number"))
    if c==1:
        print(f"{x}+{y}= {add(x,y)}")
    elif c==2:
        print(f"{x}-{y}= {sub(x,y)}")
    elif c==3:
        print(f"{x}*{y}= {mul(x,y)}")
    elif c==4:
        print(f"{x}/{y}= 1{div(x,y)}")
    else:
        print("invalid input")
if __name__=="__main__":
    calci()